const express = require("express")

const relatosrouter = express.Router();

const {storeRelatos, getRelatos} = require('../controller/relatosController');

relatosrouter.post('/store/relatos', storeRelatos);
relatosrouter.get('/get/relatos', getRelatos);



module.exports = relatosrouter;