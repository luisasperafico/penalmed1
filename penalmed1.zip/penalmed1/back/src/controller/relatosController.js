const connection = require('../config/db')
const dotenv = require('dotenv').config();

 async function storeRelatos (request, response) {

    const params = Array(
        request.body.nome,
        request.body.relato,
        request.body.imagem,
        request.body.titulo
    )

    console.log("aqui")
    const query = "INSERT INTO relatos (nome, titulo, imagem, texto) VALUES (?,?,?,?)";
    
    connection.query(query, params, (err, results) => {
        if(results) {
            response.status(200).json({
                success: true,
                message: "Sucesso!",
                data: results
            })
        } else {
            response.status(400).json({
                success: false,
                message: "Erro!",
                sql: err,
            })
        }
    })
    }

    async function getRelatos(request, response) {
        const page = parseInt(request.query.page) || 1;
        const limit = 3;
        const offset = (page - 1) * limit;
      
        const query = `
          SELECT * 
          FROM relatos
          ORDER BY data_criacao DESC 
          LIMIT ${limit} OFFSET ${offset};
        `;
      
        connection.query(query, (err, results) => {
          if (results) {
            response
              .status(201)
              .json({
                success: true,
                message: `Posts da página ${page} recuperados com sucesso`,
                data: results
              });
          } else {
            console.error('Erro na consulta SQL:', err);
      
            response
              .status(400)
              .json({
                success: false,
                message: 'Erro ao recuperar posts',
                data: err
              });
          }
        });
      }
      

module.exports = {
  storeRelatos,
  getRelatos

};