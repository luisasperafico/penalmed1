document.addEventListener('DOMContentLoaded', function() {
    const button = document.getElementById("enviar");
    const form = document.getElementById("relatos1");
  
    if (button) {
      button.onclick = async function(event) {
        event.preventDefault();
  
        const nome = form.nome.value;
        const titulo = form.titulo.value;
        const relato = form.texto.value;
        const imagem = form.imagem.files[0];
  
        const dados = { nome, titulo, relato };
  
        try {
          const formData = new FormData();
          formData.append("imagem", imagem);
          formData.append("nome", nome);
          formData.append("titulo", titulo);
          formData.append("relato", relato);
  


          const response = await fetch('http://localhost:3003/api/store/relatos', {
            method: "POST",
            headers: { "Content-type": "application/json;charset=UTF-8" },
            body: JSON.stringify(dados)
          });
  
          const content = await response.json();
  
          if (content.success) {
            alert("Sucesso!");
          } else {
            alert("Não foi criado!");
            console.log(content.sql);
          }
        } catch (error) {
          console.error("Erro na requisição:", error);
          alert("Ocorreu um erro durante o envio. Verifique o console para mais detalhes.");
        }
      };
    } else {
      console.error("Botão não encontrado no DOM.");
    }
  });



  let currentPage = 1;

document.addEventListener('DOMContentLoaded', () => {
    loadPosts(currentPage);

    document.getElementById('loadMoreButton').addEventListener('click', () => {
        currentPage++; 
        loadPosts(currentPage);
    });
});

async function loadPosts(page) {
    const response = await fetch(`http://localhost:3003/api/get/relatos?page=${page}`, {
        method: "GET",
        headers: { "Content-type": "application/json;charset=UTF-8" },
    });

    let content = await response.json();

    if (content.success) {
        const postContainer = document.getElementById('postContainer');
        content.data.forEach(post => {
            const article = document.createElement('article');
            
            const h1 = document.createElement('h1');
            h1.textContent = post.titulo;  

            const h2 = document.createElement('h2');
            h2.textContent = post.nome;

            const h3 = document.createElement('h3');
            h3.textContent = post.texto;

            article.appendChild(h1);
            article.appendChild(h2);
            postContainer.appendChild(article);
        });
    } else {
        alert(content.message);
    }
}